export enum FileExtension {
    txt = 1,
    pdf = 2,
    xlsx = 3,
    xls = 4,
    docx = 5,
    doc = 6
}
